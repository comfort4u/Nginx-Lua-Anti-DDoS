# Camfrog Fake Key Generator Remake

Tools used (to reverse):
- Visual Studio 2010
- Process Hacker
- Slyther r.0

# .prj Information
- Built with .NET Framework 4 (Client Profile)
